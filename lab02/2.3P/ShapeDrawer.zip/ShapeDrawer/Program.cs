using System;
using SplashKitSDK;

namespace ShapeDrawer
{
    public class Program
    {
        private enum ShapeKind
        {
            Rectangle,
            Circle,
            Line
        }

        public static void Main()
        {
            Window window = new Window("Shape Drawer", 800, 600);

            //2.3
            //Shape myShape = new Shape();

            //3.3
            Drawing myDrawing = new Drawing();

            ShapeKind kindToAdd = new ShapeKind();
            //kindToAdd = ShapeKind.Circle;

            do
            {
                SplashKit.ProcessEvents();
                SplashKit.ClearScreen();


                //2.3
                //if (SplashKit.MouseClicked(MouseButton.LeftButton))
                //{
                //    myShape.X = SplashKit.MouseX();
                //    myShape.Y = SplashKit.MouseY();
                //}

                //if (myShape.IsAt(SplashKit.MousePosition()) & SplashKit.KeyTyped(KeyCode.SpaceKey))
                //{
                //    myShape.Color = SplashKit.RandomRGBColor(255);
                //}

                //myShape.Draw();


                //3.3
                if (SplashKit.KeyTyped(KeyCode.RKey))
                {
                    kindToAdd = ShapeKind.Rectangle;
                }
                else if (SplashKit.KeyTyped(KeyCode.CKey))
                {
                    kindToAdd = ShapeKind.Circle;
                }
                else if (SplashKit.KeyTyped(KeyCode.LKey))
                {
                    kindToAdd = ShapeKind.Line;
                }

                    if (SplashKit.MouseClicked(MouseButton.LeftButton))
                {
                    Shape newShape;

                    //3.3
                    //newShape.X = SplashKit.MouseX();
                    //newShape.Y = SplashKit.MouseY();
                    //myDrawing.AddShape(newShape);

                    //4.1
                    if (kindToAdd == ShapeKind.Circle)
                    {
                        MyCircle newCircle = new MyCircle();
                        newCircle.X = SplashKit.MouseX();
                        newCircle.Y = SplashKit.MouseY();
                        newShape = newCircle;
                    }
                    else if (kindToAdd == ShapeKind.Line)
                    {
                        MyLine newLine = new MyLine();
                        newLine.X = SplashKit.MouseX();
                        newLine.Y = SplashKit.MouseY();
                        newShape = newLine;
                    }
                    else
                    {
                        MyRectangle newRect = new MyRectangle();
                        newRect.X = SplashKit.MouseX();
                        newRect.Y = SplashKit.MouseY();
                        newShape = newRect;
                    }
                    
                    myDrawing.AddShape(newShape);


                }

                if (SplashKit.KeyTyped(KeyCode.SpaceKey))
                {
                    myDrawing.Background = SplashKit.RandomRGBColor(255);
                }

                if (SplashKit.MouseClicked(MouseButton.RightButton))
                {
                    myDrawing.SelectShapesAt(SplashKit.MousePosition());
                }

                if (SplashKit.KeyTyped(KeyCode.DeleteKey) | SplashKit.KeyTyped(KeyCode.BackspaceKey))
                {
                    foreach (Shape s in myDrawing.SelectedShapes)
                    {
                        myDrawing.RemoveShape(s);
                    }
                }

                myDrawing.Draw();


                SplashKit.RefreshScreen();
            } while (!window.CloseRequested);
        }
    }
}
