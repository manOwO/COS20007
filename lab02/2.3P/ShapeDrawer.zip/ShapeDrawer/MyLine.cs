﻿using System;
using SplashKitSDK;

namespace ShapeDrawer
{
	public class MyLine : Shape
	{
		public MyLine()
		{
		}

        public override bool IsAt(Point2D pt)
        {
            Point2D _shapePosition = new Point2D();
            _shapePosition.X = X;
            _shapePosition.Y = Y;
            Point2D _endPosition = new Point2D();
            _endPosition.X = X + 100;
            _endPosition.Y = Y + 100;
            return SplashKit.PointOnLine(pt, SplashKit.LineFrom(_shapePosition, _endPosition));
        }

        public override void Draw()
        {
            if (Selected)
                DrawOutline();
            SplashKit.DrawLine(Color, X, Y, X + 100, Y + 100, SplashKit.OptionLineWidth(5));
        }

        public override void DrawOutline()
        {
            SplashKit.DrawLine(Color.Black, X, Y, X + 100, Y + 100, SplashKit.OptionLineWidth(7));
        }
    }
}

